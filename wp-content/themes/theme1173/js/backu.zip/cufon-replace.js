/*Cufon.replace('#header-banners h3, .primary_content_wrap .widget h3, h2', { fontFamily: 'M+ 1c Regular', hover:true });*/
/*Cufon.replace('#top-sidebar .widget_text h3, h1, #right-banners h3', { fontFamily: 'M+ 1pHeavy' });*/
Cufon.replace('nav.primary > ul > li > a, #right-banners ul li strong', { fontFamily: 'Franchise', hover:true });
Cufon.replace('#post-author h3', { fontFamily: 'M+ 1c Regular', hover:true });